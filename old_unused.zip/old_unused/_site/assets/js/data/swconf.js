const swconf = { purge: true };
